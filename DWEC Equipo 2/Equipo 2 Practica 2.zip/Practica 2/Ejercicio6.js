var numAleatorio = Math.floor(Math.random() * 1000)
alert(numAleatorio)
do{
    var num = parseInt(prompt("Ingresa un número del 1 al 1000"))
    if(numAleatorio != num)
        alert("No has adivinado el numero")

}while(numeroAleatorio != num)
alert("Has adivinado el numero")