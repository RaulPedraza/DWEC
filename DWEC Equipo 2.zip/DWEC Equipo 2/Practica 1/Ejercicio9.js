do{let nombre=prompt('Introduzca nombre:')
let apellido=prompt('Introduzca apellido')
alert('su nombre es '+nombre+' y su apellido es '+apellido)
var respuesta=confirm('desea finalizar la aplicacion?')}
while(!respuesta)
