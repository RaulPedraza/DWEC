var texto.inic="Presentamos el producto";
var 3aux=4,numero,aux1="ana;
var emp est=true,var=5;
var aux3_1=5;Nom_Primero;
var _texto=entrada;
aux3_1="Pedro";
Nom_Primero=aux3_1;
aux1=aux3_1;*/

var texto_inic="Presentamos el producto";/*En el nombre de la varianle para simular el espacio en blanco no se puede usar un punto.
Sol se puede usar el simbolo del $ o una barrabaja(_).*/
var aux3=4,numero,aux1="ana";/*El nombre de la variable no puede empezar por un numero*/
var emp_est=true/*En el nombre o identificador de la variable no puede haber un espacio en blanco hay que reemplazarlo por el simbolo del $ o una barrabaja(_)
var num=5;/*una variable no puede establecerse sin asignarle un nombre o identificador*/
var aux3_1=5,Nom_Primero;/*Para la declaracion de variables en una sola linea no se pueden separar las diferentes variables mediante el simbolo";"*/
var _texto="entrada";
aux3_1="Pedro";
Nom_Primero=aux3_1;
aux1=aux3_1;