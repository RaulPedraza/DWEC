let n1=parseInt(prompt('Introduzca la altura del rectangulo'))
let n2=parseInt(prompt('Introduzca la base del rectangulo'))
alert('el area del rectangulo es: '+(n2*n1))


