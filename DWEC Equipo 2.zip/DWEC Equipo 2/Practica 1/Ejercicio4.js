var aux1="Oveja que bala",aux2="bocado que pierde";
var num1 =8, num2 =5, resultado , operando="20";
alert(aux1+aux2+"<br >"); //Oveja que balabocado que pierde<br >
alert (num1+num2+"<br >");//13<br >
num1=num1+num2;
resultado =num1+num2;
alert (num1+"-"+num2+"-"+ resultado );//13-5-18
resultado =operando+num1;
alert ( resultado );//2013
resultado =parseInt(operando)+num1;
alert ( resultado ); //33