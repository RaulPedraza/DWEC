var puntos="340";
var descuento =20;
// Hacer lo necesario para restar "puntos" de " descuento "
resultado = parseInt(puntos) - descuento;
// Mostrar por pantalla un mensaje del tipo:
// Los puntos obtenidos son 340, el descuento es 20 y el resultado final es 320
alert ("Los puntos obtenidos son " + puntos + ", el descuento es " + descuento + " y el resultado final es " + resultado);
