var num1
num1=prompt("Introduce un numero")
var num2
num2=prompt("Introduce otro numero")
alert("La suma de los dos numeros es = "+(parseInt(num1)+parseInt(num2)))
alert("La resta de los dos numeros es = "+(parseInt(num1)-parseInt(num2)))
alert("La multiplicación de los dos numeros es = "+(parseInt(num1)*parseInt(num2)))
alert("La división de los dos numeros es = "+(parseInt(num1)/parseInt(num2)))
alert("Elresto de los dos numeros es = "+(parseInt(num1)%parseInt(num2)))