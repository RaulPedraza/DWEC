var num1
var num2
var suma;
num1 = prompt("introduzca un número")
num2 = prompt("Introduzca otro número")
suma = parseInt(num1) + parseInt(num2);
alert("La suma de ambos números es " + suma)
