var num1
var num2
num1 = prompt("introduzca un número")
num2 = prompt("Introduzca otro número")

alert("La división es: "+ (num1/num2))

//La respuesta que da al dividir con letras es NaN ya que nos da un error. La respuesta que da
//al dividir un número con 0 es Infinity y al dividir dos letras es NaN también