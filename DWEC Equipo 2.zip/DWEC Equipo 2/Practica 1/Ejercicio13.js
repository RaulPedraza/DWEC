var Pepe;
var PEPE="Hola que tal ";
var pepE =75.47;
var pEpe=" ¿Como estás?";
Pepe=PEPE+pEpe;

alert("PEPE="+PEPE);
alert("PEPE es "+typeof(PEPE));

alert("pepE="+pepE);
alert("pepE es "+typeof(pepE));
alert("pEpe="+pEpe);
alert("pEpe es "+typeof(pEpe));
alert("Pepe="+Pepe);
alert("Pepe es "+typeof(Pepe));
