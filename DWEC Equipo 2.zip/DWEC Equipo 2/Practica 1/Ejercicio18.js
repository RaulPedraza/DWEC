var a, b;
a = prompt("Escribe la base:")
b = prompt("Escribe la altura:")//prompt no estaba bien escrito le faltaba la t del final
alert("Area= "+(a*b/2));//Faltaba el parentesis que cerraba el alert
