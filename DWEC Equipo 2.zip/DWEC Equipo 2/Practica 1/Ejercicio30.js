var num1=1
var num2=2
var num3=3
var num4=4
var num5=5
var num6=6

var array = new Array(3);
array[0] = new Array(3);
array[1] = new Array(3);
array [0][0]=num1;
array [0][1]=num2;
array [0][2]=num1+num2;
array [1][0]=num3;
array [1][1]=num4;
array [1][2]=num3+num4;
alert(array [0][0].toString()+" + "+array [0][1].toString()+" = "+array [0][2].toString()+"\n"+array [1][0].toString()+" + "+array [1][1].toString()+" = "+array [1][2].toString())
