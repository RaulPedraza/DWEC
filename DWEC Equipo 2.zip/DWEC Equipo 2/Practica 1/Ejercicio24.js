var num
let factorial = 1
num = prompt("Introduzca un número")
    for (i=1; i<=num; i++) {
        factorial = factorial * i; 
    }
    alert(factorial) 