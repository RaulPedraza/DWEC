var n1 =57; // número en base 10
var n2 =012345; // base 8, porque empieza por 0
var n3=0xFF32; // base 16, porque empieza por 0x

alert("número decimal= " + n1);
alert("el 12345 en base 8 es en decimal= "+n2);
alert("el FF32 en base 16 es en decimal= "+n3);

/* Observa que al escribir una variable numérica en un "alert"
siempre nos da el número en decimal , aunque sea en octal o
hexadecimal */
