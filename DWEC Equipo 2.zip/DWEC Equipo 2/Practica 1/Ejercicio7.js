var nombre
nombre=prompt("Introduce un nombre")
var edad
edad=prompt("Introduce una edad")
var incremento
incremento=prompt("Introduce el incremento")
var nuevaEdad=parseInt(edad)+parseInt(incremento)
alert(nombre+" tiene "+edad+" años y dentro de "+incremento+" años tendrá "+nuevaedad)