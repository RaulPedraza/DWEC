var nombre="Elena";
var anos="20";
var aux =2;
/* Hacer lo necesario para que se vea el siguiente mensaje
utilizando las variables correspondientes :
Elena tiene 20 años y dentro de 2 años tendra 22 */
alert(nombre+" tiene "+anos+" y dentro de "+aux+" años tendra "+(parseInt(anos)+aux));
