var num1
var num2
num1 = prompt("introduzca un número")
alert("El doble del número es: "+ Math.imul(num1,2) +", el triple: "+ Math.imul(num1,3) +", el cuádruple: "+ Math.imul(num1,4))
