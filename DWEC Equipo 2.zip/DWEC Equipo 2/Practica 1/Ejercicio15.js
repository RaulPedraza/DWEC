var num1
num1=prompt("Introduce un numero")
var num2
num2=prompt("Introduce otro numero")
alert("La resta de los dos numeros es = "+(parseInt(num1)-parseInt(num2)))
/*Si en vez de dividir dos numeros dividimos dos textos devuelve NaN*/ 