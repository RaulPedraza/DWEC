var num
num=prompt("Introduce un numero")
if(num%2==0)
	alert("el numero es par")
else
	alert("el numero es impar")