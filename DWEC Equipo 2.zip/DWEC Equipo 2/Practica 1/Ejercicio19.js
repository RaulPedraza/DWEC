var radio=prompt('introduce el radio del circulo')
alert('el perimetro de la circunferencia es: '+(2*Math.PI*radio)+' \ny si area es : '+(Math.PI*Math.pow(radio,2)))